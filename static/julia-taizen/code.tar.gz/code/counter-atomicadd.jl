# アトミック操作によるカウンター
mutable struct Counter
    @atomic count::Int
end

counter = Counter(0)
Threads.@threads for i in 1:1_000_000
    @atomic counter.count += 1
end
@show counter.count

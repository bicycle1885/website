using .Threads: Condition, @spawn

@sync begin
    cond = Condition()
    ready = false

    # イベント通知をするタスク
    @spawn begin
        sleep(1)
        @lock cond begin
            ready = true
            println("Ready!")
            # イベント通知
            notify(cond)
        end
    end

    # イベント通知を受けるタスク
    for i in 1:8
        @spawn begin
            @lock cond while !ready
                wait(cond)
            end
            # イベント通知後の処理
            print("Go!")
        end
    end
end
println()

# 引数の最小値を返す関数
function min(x1, xs...)
    ret = x1
    for x in xs
        if isless(x, ret)
            ret = x
        end
    end
    return ret
end

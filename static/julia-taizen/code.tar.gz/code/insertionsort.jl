# 挿入ソート
function insertionsort(xs)
    xs = copy(xs)
    for i in 2:lastindex(xs)
        x = xs[i]
        while i > 1 && xs[i-1] > x
            xs[i] = xs[i-1]
            i -= 1
        end
        xs[i] = x
    end
    return xs
end

include("parsum.jl")

using Random: seed!
using BenchmarkTools: @belapsed
seed!(1234)
A = randn(2^20, 128)
n = nthreads()
println("nthreads\tk\telapsed")
for k in 0:7
    elapsed = @belapsed parsum($A, $k)
    println("$n\t$k\t$elapsed")
end

#!/usr/bin/env bash

set -ex

julia -t1 benchmark.jl >benchmark-t1.txt
julia -t4 benchmark.jl >benchmark-t4.txt

using .Threads: nthreads, @threads, threadid

function parsum(A, k)
    s = zeros(eltype(A), (nthreads() - 1) << k + 1)
    @threads :static for j in axes(A, 2)
        offset = (threadid() - 1) << k + 1
        # 行列Aのj列目の総和を計算
        @inbounds for i in axes(A, 1)
            s[offset] += A[i,j]
        end
    end
    return sum(s)
end

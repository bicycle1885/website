# n以下の素数を返す
function primes(n)
    # 素数の候補を配列で保持
    list = trues(n)
    # 1は素数ではないので削除
    list[1] = false
    # 最初の素数
    p = 2
    while p ≤ isqrt(n)
        # 2p, 3p, … は素数ではないので削除
        for i in 2p:p:n
            list[i] = false
        end
        #@show p bitstring(list)  # 変数の内容を表示する
        # 候補から最小の自然数（素数）を選ぶ
        p = findnext(list, p + 1)
    end
    # 残った素数の候補を返す
    return findall(list)
end

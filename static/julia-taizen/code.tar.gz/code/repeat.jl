macro repeat(n, ex)
    quote
        for _ in 1:$(esc(n))
            $(esc(ex))
        end
    end
end

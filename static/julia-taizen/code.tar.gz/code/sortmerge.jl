# ソート済の配列A,Bの要素を配列Cに昇順にコピー
function sortmerge!(C, A, B)
    @assert length(A) + length(B) == length(C)
    i, j, k = firstindex.((A, B, C))
    @inbounds while i ≤ lastindex(A) && j ≤ lastindex(B)
        a = A[i]
        b = B[j]
        if isless(a, b)
            C[k] = a
            i += 1
        else
            C[k] = b
            j += 1
        end
        k += 1
    end
    if i ≤ lastindex(A)
        copyto!(C, k, A, i, lastindex(A) - i + 1)
    else
        copyto!(C, k, B, j, lastindex(B) - j + 1)
    end
    return C
end

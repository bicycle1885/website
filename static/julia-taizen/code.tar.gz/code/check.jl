# 注：この定義は問題あり
macro check(ex)
    code = string(ex)  # 式を文字列化
    quote
        print($code, " → ")
        if $ex
            println("GOOD")
        else
            println("BAD")
        end
    end
end

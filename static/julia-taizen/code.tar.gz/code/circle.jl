struct Circle
    r::Float64   # 半径
    cx::Float64  # 中心のx座標
    cy::Float64  # 中心のy座標

    # 内部コンストラクタ
    function Circle(r::Real, cx::Real, cy::Real)
        r ≥ 0 || throw(ArgumentError("r must be non-negative"))
        return new(r, cx, cy)
    end
end

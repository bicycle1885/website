# コンポジション型
struct Composition{T <: Real} <: AbstractVector{T}
    data::Vector{T}

    function Composition(x)
        c = x ./ sum(x)
        return new{eltype(c)}(c)
    end
end

# スカラー倍
Base.:*(α::Real, x::Composition) = Composition(x .^ α)
Base.:*(x::Composition, α::Real) = Composition(x .^ α)

# ベクトル和
Base.:+(x::Composition, y::Composition) = Composition(x .* y)

# ベクトル和の逆元とベクトル差
Base.:-(x::Composition) = Composition(inv.(x))
Base.:-(x::Composition, y::Composition) = x + (-y)

Base.size(x::Composition) = size(x.data)
Base.getindex(x::Composition, i::Integer) = x.data[i]

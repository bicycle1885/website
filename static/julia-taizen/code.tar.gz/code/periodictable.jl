# 元素（chemical element）
struct ChemElem
    number::Int
    symbol::String
end

# 周期表（periodic table）
struct PeriodicTable
    elements::Vector{ChemElem}  # 元素
    groups::Vector{Int}         # 族
    periods::Vector{Int}        # 周期
end

# 簡単のため原子番号1−6のみ
table = PeriodicTable(
    # elements
    [ChemElem(1, "H"), ChemElem(2, "He"), ChemElem(3, "Li"),
     ChemElem(4, "Be"), ChemElem(5, "B"), ChemElem(6, "C")],
    # groups
    [1, 18, 3, 4, 13, 14],
    # periods
    [1, 1, 2, 2, 2, 2]
)

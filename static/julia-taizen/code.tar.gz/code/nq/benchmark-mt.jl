#!/usr/bin/env julia

include("nqueens-mt.jl")

N = 15  # board size
nthreads = Threads.nthreads()
name = Symbol(ARGS[1])
func = @eval $(Symbol(:nqueens_, name))
@elapsed func(8)  # compile
for _ in 1:3
    elapsed = @elapsed nsols = func(N)
    println("$nthreads\t$name\t$nsols\t$elapsed")
end

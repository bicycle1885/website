# フラット並列（MapReduce）
function nqueens_flat(n)
    n ≤ 1 && return Int(n == 1)
    tasks = map(1:n) do rank
        # (1, j)に最初のクイーンがあるタスクを作成
        @spawn begin
            ranks = zeros(Int, n)
            ranks[1] = rank
            return solve(ranks, 2)
        end
    end
    return sum(fetch(task)::Int for task in tasks)
end

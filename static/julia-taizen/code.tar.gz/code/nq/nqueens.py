#!/usr/bin/env python3

def solve(ranks, file):
    n = len(ranks)
    nsols = 0
    for rank in range(n):
        attacked = False
        for i in range(file):
            r = rank - ranks[i]
            if r == 0 or file - i == abs(r):
                attacked = True
                break
        if not attacked:
            ranks[file] = rank
            if file < n - 1:
                nsols += solve(ranks, file + 1)
            else:
                nsols += 1
    return nsols


def nqueens(n):
    return solve([0] * n, 0)


if __name__ == '__main__':
    import sys
    n = int(sys.argv[1])
    print(f"{n}: {nqueens(n)}")

using DataFrames
using CSV
using PyPlot

function category(exe)
    for (suffix, name) in [
            (".jl",     "Julia"),
            ("-cpp-O1", "C++ -O1"),
            ("-cpp-O3", "C++ -O3"),
            (".py",     "Python"),
        ]
        endswith(exe, suffix) && return name
    end
    @assert false
end

data = DataFrame(CSV.File("benchmark.log", delim = '\t'))

elapsed = combine(groupby(data, [:exe, :size]), :elapsed => minimum, renamecols = false)
elapsed.name = category.(elapsed.exe)
fig, ax = subplots(figsize = (10, 6))
names = ["Julia", "C++ -O1", "C++ -O3", "Python"]
for (i, name) in enumerate(names)
    subset = elapsed[elapsed.name .== name,:]
    height = 1/6
    ax.barh(subset.size .+ i .* height .- 5height/2, subset.elapsed; height, color = "C$(i-1)", label = name)
end
ax.legend()
ax.set_xscale("log")
ax.set_xlabel("elapsed [s]")
ax.set_ylabel(raw"$N$")
ax.invert_yaxis()
ax.grid(alpha = 1/2, axis = "x")
ax.spines["top"].set_visible(false)
ax.spines["right"].set_visible(false)
fig.savefig("plot.pdf", bbox_inches = "tight")
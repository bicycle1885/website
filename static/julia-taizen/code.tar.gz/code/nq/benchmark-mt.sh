#!/usr/bin/env bash

set -eu

{
echo -e 'nthreads\tname\tnsols\telapsed'
julia benchmark-mt.jl serial
for name in flat nested
do
    for t in $(seq 1 16)
    do
        julia -t $t benchmark-mt.jl $name
    done
done
} | tee benchmark-mt.txt

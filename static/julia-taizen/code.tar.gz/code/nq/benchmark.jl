#!/usr/bin/env julia

function run_with_timelimit(cmd, logfile)
    @assert !isnothing(Sys.which("timeout"))
    istimeout(ex) =
        ex isa ProcessFailedException &&
        ex.procs[1].exitcode == 124
    # timeout in 60 mins
    pl = pipeline(`timeout 60m $(cmd)`, stdout = logfile, append = true)
    elapsed = missing
    try
        elapsed = @elapsed run(pl)
    catch ex
        istimeout(ex) || rethrow()
    end
    return elapsed
end

println("exe\tsize\telapsed")  # header
for suffix in [".jl", "-cpp-O1", "-cpp-O3", ".py"]
    exe = string("./nqueens", suffix)
    logfile = "$(exe).log"
    rm(logfile, force = true)
    for size in 11:16
        cmd = `$exe $size`
        # warm up
        elapsed = run_with_timelimit(cmd, "warmup.log")
        rm("warmup.log", force = true)
        ismissing(elapsed) && break  # gives up
        # start to measure elapsed time
        elapsed = run_with_timelimit(cmd, logfile)
        println(exe, '\t', size, '\t', elapsed)
    end
end

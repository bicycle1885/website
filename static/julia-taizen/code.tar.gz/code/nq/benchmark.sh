#!/usr/bin/env bash

./benchmark.jl | tee benchmark.txt

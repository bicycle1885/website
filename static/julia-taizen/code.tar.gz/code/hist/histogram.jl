include("histogram-serial.jl")
include("histogram-lock.jl")
include("histogram-mapreduce.jl")

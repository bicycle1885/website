using .Threads: @spawn, nthreads

# MapReduceパターン
function histogram_mapreduce(img::Img; p = nthreads())
    # Map
    n = cld(length(img), p)
    parts = Iterators.partition(eachindex(img), n)
    tasks = map(parts) do part
        @spawn begin
            hist_r = zeros(Int, 256)
            hist_g = zeros(Int, 256)
            hist_b = zeros(Int, 256)
            @inbounds for i in part
                x = img[i]  # 画素（pixel）
                hist_r[reinterpret(UInt8, x.r)+1] += 1
                hist_g[reinterpret(UInt8, x.g)+1] += 1
                hist_b[reinterpret(UInt8, x.b)+1] += 1
            end
            hist_r, hist_g, hist_b
        end
    end

    # Reduce
    function add!((r1, g1, b1), (r2, g2, b2))
        r1 .+= r2
        g1 .+= g2
        b1 .+= b2
        return r1, g1, b1
    end
    return foldl(add!, fetch(task)::NTuple{3, Vector{Int}} for task in tasks)
end

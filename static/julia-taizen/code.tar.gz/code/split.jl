# SubString版
function split_sub(isprefix, s)
    pos = findfirst(!isprefix, s)
    pos === nothing && return SubString(s), SubString("")
    return @view(s[begin:prevind(s, pos)]), @view(s[pos:end])
end

# String版
function split_str(isprefix, s)
    pos = findfirst(!isprefix, s)
    pos === nothing && return s, ""
    return s[begin:prevind(s, pos)], s[pos:end]
end

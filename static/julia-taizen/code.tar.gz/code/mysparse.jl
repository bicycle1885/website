# sparse関数のように振る舞う関数
function mysparse(I, J, V, m = maximum(I), n = maximum(J))
    M = spzeros(m, n)
    for (i, j, v) in zip(I, J, V)
        M[i,j] = v
    end
    return M
end

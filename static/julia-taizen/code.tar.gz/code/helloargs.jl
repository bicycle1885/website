#!/usr/bin/env julia
name1 = ARGS[1]
name2 = ARGS[2]
println("こんにちは、$(name1)さんと$(name2)さん")

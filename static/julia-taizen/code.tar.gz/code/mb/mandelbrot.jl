const N = 1000

# マンデルブロ集合に含まれるか計算
function mandelbrot(c::Complex; maxiters = N)
    k = 0
    z = zero(c)
    while k < maxiters && abs2(z) ≤ 4
        z = z*z + c
        k += 1
    end
    return maxiters - k  # 0なら収束と判定
end

#!/usr/bin/env -S julia -t8

include("mandelbrot.jl")
include("plot-seq.jl")
include("plot-par1.jl")
include("plot-par2.jl")

# check
x = y = range(-2, 2, length = 101)
@assert plot_seq(x, y) == plot_par1(x, y) == plot_par2(x, y)

using Images
x = range(-2.0, 0.8, length = 10001)
y = range(-1.4, 1.4, length = 10001)
img = plot_par2(x, y, maxiters = N)
colors = colormap("Blues", N, logscale = true)
colored = zeros(RGB{Float64}, size(img))
@. colored[img > 0] = colors[img[img > 0] + 1]
save("mandelbrot.png", colored)

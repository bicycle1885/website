# 並列実行版2
function plot_par2(x, y; maxiters = N, blocksize = nothing)
    m, n = length.((y, x))
    if isnothing(blocksize)
        # スレッド数x32個の区画に分割
        p = Threads.nthreads()
        blocksize = cld(n, 32p)
    end
    chan = Channel(spawn = true) do chan
        # y軸と平行に分割
        for J in Iterators.partition(1:n, blocksize)
            put!(chan, J)
        end
    end
    img = zeros(Int16, m, n)
    Threads.foreach(chan) do J
        for j in J, i in 1:m
            c = complex(x[j], y[i])
            img[i,j] = mandelbrot(c; maxiters)
        end
    end
    return img
end

using JSON

# JSON形式の文字列のパース
langs = JSON.parse("""
{
    "julia": {
        "first-release": 2012,
        "creators": [
            "Jeff Bezanson",
            "Stefen Karpinski",
            "Viral Shah"
        ]
    },
    "python": {
        "first-release": 1991,
        "creators": ["Guido van Rossum"]
    }
}
""")

# JuliaのオブジェクトからJSON形式の文字列への変換
JSON.json(langs)

function printchars(s)
    fi, li = firstindex(s), lastindex(s)
    i = fi
    while i ≤ li
        i > fi && print('/')
        print(s[i])
        i = nextind(s, i)
    end
end

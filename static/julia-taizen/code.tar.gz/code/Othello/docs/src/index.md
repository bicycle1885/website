```@meta
CurrentModule = Othello
```

# Othello

Documentation for [Othello](https://github.com/bicycle1885/Othello.jl).

```@index
```

```@autodocs
Modules = [Othello]
```

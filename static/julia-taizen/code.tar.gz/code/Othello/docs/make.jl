using Othello
using Documenter

DocMeta.setdocmeta!(Othello, :DocTestSetup, :(using Othello); recursive=true)

makedocs(;
    modules=[Othello],
    authors="Kenta Sato <bicycle1885@gmail.com> and contributors",
    repo="https://github.com/bicycle1885/Othello.jl/blob/{commit}{path}#{line}",
    sitename="Othello.jl",
    format=Documenter.HTML(;
        prettyurls=get(ENV, "CI", "false") == "true",
        canonical="https://bicycle1885.github.io/Othello.jl",
        assets=String[],
    ),
    pages=[
        "Home" => "index.md",
    ],
)

deploydocs(;
    repo="github.com/bicycle1885/Othello.jl",
    devbranch="main",
)

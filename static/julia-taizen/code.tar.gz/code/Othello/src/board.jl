# オセロ盤
# -------

# オセロ盤のデータ型
struct Board
    data::Matrix{Disk}  # 石の行列（2次元配列）でオセロ盤を表現
end

# オセロ盤を作るコンストラクタ
function Board()
    board = Board(fill(DISK_EMPTY, (N, N)))
    # 石の初期配置
    board[('d', 5)] = board[('e', 4)] = DISK_BLACK
    board[('d', 4)] = board[('e', 5)] = DISK_WHITE
    return board
end

# オセロ盤の石を見る操作
Base.getindex(board::Board, pos::Position) =
    board.data[pos2idx(pos)...]

# オセロ盤に石を置く操作
function Base.setindex!(board::Board, disk::Disk, pos::Position)
    board.data[pos2idx(pos)...] = disk
    return board
end

# オセロ盤の表示
function Base.show(output::IO, board::Board)
    disks = countdisks(board)
    print(output, "Board with $(disks.black) blacks")
    print(output, " and $(disks.white) whites:\n")
    print(output, "  ")
    for c in COLS
        print(output, ' ', c)  # 列の英字表示
    end
    for r in ROWS
        print(output, "\n ", r)  # 行の数字表示
        for c in COLS
            print(output, ' ', board[(c, r)])
        end
    end
end

# 盤上にある石のカウント
function countdisks(board::Board)
    black = white = 0
    for c in COLS, r in ROWS
        disk = board[(c, r)]
        if isblack(disk)
            black += 1
        elseif iswhite(disk)
            white += 1
        end
    end
    # 名前付きタプルを返す
    return (black = black, white = white)
end

# 石の打ち方
# --------

# 方向dirに対してひっくり返せる石を探索
function flips(board::Board, disk::Disk, pos::Position, dir::NTuple{2, Int})
    dir == (0, 0) && return nothing
    nflips = 0  # ひっくり返せる石の数
    # 自分の石を探索
    next = pos .+ dir
    while isonboard(next) && board[next] == flip(disk)
        nflips += 1
        next = next .+ dir
    end
    # 相手の石を挟めているかをチェック
    if nflips > 0 && isonboard(next) && board[next] == disk
        # ペアになる石の位置を返す
        return next
    else
        return nothing
    end
end

# 有効手か判定
function isvalidmove(board::Board, disk::Disk, pos::Position)
    isonboard(pos) &&
    !isblack(board[pos]) &&
    !iswhite(board[pos]) || return false
    dirs = ((u, v) for u in -1:1 for v in -1:1 if !(u == v == 0))
    return !all(isnothing, flips(board, disk, pos, dir) for dir in dirs)
end

# 石diskを位置posに置いたときの盤面boardの更新
function move!(board::Board, disk::Disk, pos::Position)
    isvalidmove(board, disk, pos) || throw(ArgumentError("invalid move"))
    board[pos] = disk
    for u in -1:1, v in -1:1
        dir = (u, v)  # ひっくり返す方向
        pair = flips(board, disk, pos, dir)
        isnothing(pair) && continue
        next = pos .+ dir
        while next != pair
            board[next] = disk
            next = next .+ dir
        end
    end
    return board
end

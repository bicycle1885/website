# 盤上の位置
# --------

const Position = Tuple{Char, Int}  # 位置をタプルで表現
const N = 8                        # 盤の1辺のサイズ
const ROWS = 1:N                   # 行の範囲
const COLS = 'a':'a'+N-1           # 列の範囲

# 位置posを行列のインデックスに変換
pos2idx(pos::Position) = (pos[2], pos[1] - 'a' + 1)

# 位置posが盤上にあるかを判定
isonboard(pos::Position) = pos[2] ∈ ROWS && pos[1] ∈ COLS

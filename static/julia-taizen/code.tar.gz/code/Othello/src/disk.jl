# オセロ石
# -------

# 石は文字で表現
const Disk = Char
const DISK_EMPTY = '\u22c5'  # 空き '⋅'
const DISK_BLACK = '\u25cf'  # 黒石 '●'
const DISK_WHITE = '\u25cb'  # 白石 '○'

# 石を判定する便利関数
isblack(disk::Disk) = disk == DISK_BLACK
iswhite(disk::Disk) = disk == DISK_WHITE

# 石をひっくり返す関数
flip(disk::Disk) =
    isblack(disk) ? DISK_WHITE :
    iswhite(disk) ? DISK_BLACK :
    throw(ArgumentError("not flippable"))

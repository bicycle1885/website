# Othello

[![Stable](https://img.shields.io/badge/docs-stable-blue.svg)](https://bicycle1885.github.io/Othello.jl/stable)
[![Dev](https://img.shields.io/badge/docs-dev-blue.svg)](https://bicycle1885.github.io/Othello.jl/dev)
[![Build Status](https://github.com/bicycle1885/Othello.jl/actions/workflows/CI.yml/badge.svg?branch=main)](https://github.com/bicycle1885/Othello.jl/actions/workflows/CI.yml?query=branch%3Amain)
[![Coverage](https://codecov.io/gh/bicycle1885/Othello.jl/branch/main/graph/badge.svg)](https://codecov.io/gh/bicycle1885/Othello.jl)

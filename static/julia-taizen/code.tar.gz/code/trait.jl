# トレイトの定義
abstract type Trait end
struct TraitA <: Trait end
struct TraitB <: Trait end

# トレイトを利用する関数
f(x) = _f(Trait(typeof(x)), x)
_f(::TraitA, x) = "Trait A"
_f(::TraitB, x) = "Trait B"

# トレイトを実装する型
struct Foo end
Trait(::Type{Foo}) = TraitA()
struct Bar end
Trait(::Type{Bar}) = TraitB()
struct Baz end
Trait(::Type{Baz}) = TraitB()

using Logging

# ファイルに出力するロガー
file = open("messages.log", "w")
logger = ConsoleLogger(file, Logging.Debug)
with_logger(logger) do
    @info "Info message"
    @debug "Debug message"
end
close(file)

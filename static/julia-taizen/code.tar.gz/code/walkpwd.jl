# pwd()以下のすべてのディレクトリとファイルを再帰的に探索
for (root, dirs, files) in walkdir(pwd())
    # root直下のディレクトリを列挙
    for dir in dirs
        println("d:", joinpath(root, dir))
    end
    # root直下のファイルを列挙
    for file in files
        println("f:", joinpath(root, file))
    end
end

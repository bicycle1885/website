# チャネルに値を詰める生産者
chan = Channel{Int}() do chan
    for i in 1:10
        put!(chan, i)
    end
end

# チャネルから値を取り出す消費者
@sync for label in 'A':'E'
    @async for data in chan
        println(label, ": ", data)
    end
end

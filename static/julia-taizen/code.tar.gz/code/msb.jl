# 最上位ビット（most significant bit）を取得する関数
for T in [UInt8, UInt16, UInt32, UInt64, UInt128]
    @eval msb(x::$T) = x >> (sizeof($T) * 8 - 1)
end

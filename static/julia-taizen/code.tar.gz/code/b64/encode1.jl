# Base64符号化関数（バージョン1）
function encode1(data::AbstractVector{UInt8})
    str = zeros(UInt8, cld(sizeof(data), 3) * 4)
    i = firstindex(data)
    j = firstindex(str)
    k = 0     # 持ち越されたビットの長さ
    h = 0x00  # 持ち越されたビット
    @inbounds while i ≤ lastindex(data)
        x = data[i]
        str[j] = hex2char(h | x >> (k + 2))
        j += 1
        k += 2; k %= 8
        h = 0x3f & x << (6 - k)
        k ≤ 4 && (i += 1)
    end
    # 余ったビットの処理
    k == 0 || (str[j] = hex2char(h); j += 1)
    # パディング処理
    j ≤ lastindex(str) && (str[j] = UInt('='); j += 1)
    j ≤ lastindex(str) && (str[j] = UInt('='); j += 1)
    return str
end

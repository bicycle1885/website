using Test

include("base64.jl")

@test encode1(b"J") == b"Sg=="
@test encode2(b"J") == b"Sg=="
@test encode3(b"J") == b"Sg=="
@test encode1(b"Julia言語") == b"SnVsaWHoqIDoqp4="
@test encode2(b"Julia言語") == b"SnVsaWHoqIDoqp4="
@test encode3(b"Julia言語") == b"SnVsaWHoqIDoqp4="
@test encode1(b"Julia言語!") == b"SnVsaWHoqIDoqp4h"
@test encode2(b"Julia言語!") == b"SnVsaWHoqIDoqp4h"
@test encode3(b"Julia言語!") == b"SnVsaWHoqIDoqp4h"
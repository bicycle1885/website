# 6ビットから1文字への変換関数
hex2char(h::UInt8) =
    h < 0x1a ? UInt8('A') + h        :
    h < 0x34 ? UInt8('a') + h - 0x1a :
    h < 0x3e ? UInt8('0') + h - 0x34 :
    h ≡ 0x3e ? UInt8('+') : UInt8('/')

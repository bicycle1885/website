# 長さ4のベクトル
struct Vec4{T}
    x::T
    y::T
    z::T
    w::T
end

# Vec4型のnorm
norm(v::Vec4) =
    sqrt(abs2(v.x) + abs2(v.y) + abs2(v.z) + abs2(v.w))

# Vector型のnorm
function norm(v::AbstractVector)
    s = zero(eltype(v))
    for x in v
        s += abs2(x)
    end
    return sqrt(s)
end

# 型が安定しているsum関数の実装
function sum_stable(xs)
    s = zero(eltype(xs))
    for x in xs
        s += x
    end
    return s
end

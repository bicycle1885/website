# 標準ライブラリの読込み
using LinearAlgebra
using Statistics

# 主成分分析（データXは各列が観測値の行列）
function pca(X)
    # 中心化（各行の平均値を差し引く）
    X = X .- mean(X, dims = 2)
    # 特異値分解
    U, = svd(X)
    # 射影（i行目が第i主成分に対応）
    return U'X
end
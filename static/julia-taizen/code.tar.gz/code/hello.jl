#!/usr/bin/env julia
println("hello, world")
println("こんにちは、世界")

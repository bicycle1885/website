module LZMA

const liblzma = "liblzma"

# lzma/container.h
const FLAG_CONCATENATED = UInt32(0x08)

# lzma/check.h
@enum Check begin
    CHECK_NONE   = 0
    CHECK_CRC32  = 1
    CHECK_CRC64  = 4
    CHECK_SHA256 = 10
end

# lzma/base.h
@enum Ret begin
    RET_OK                 = 0
    RET_STREAM_END         = 1
    RET_NO_CHECK           = 2
    RET_UNSUPPORTED_CHECK  = 3
    RET_GET_CHECK          = 4
    RET_MEM_ERROR          = 5
    RET_MEMLIMIT_ERROR     = 6
    RET_FORMAT_ERROR       = 7
    RET_OPTIONS_ERROR      = 8
    RET_DATA_ERROR         = 9
    RET_BUF_ERROR          = 10
    RET_PROG_ERROR         = 11
end

# lzma/base.h
@enum Action begin
    ACTION_RUN          = 0
    ACTION_SYNC_FLUSH   = 1
    ACTION_FULL_FLUSH   = 2
    ACTION_FULL_BARRIER = 4
    ACTION_FINISH       = 3
end

# lzma/base.h
mutable struct Stream
    next_in::Ptr{UInt8}
    avail_in::Csize_t
    total_in::UInt64

    next_out::Ptr{UInt8}
    avail_out::Csize_t
    total_out::UInt64

    allocator::Ptr{Cvoid}

    internal::Ptr{Cvoid}

    reserved_ptr::NTuple{4, Ptr{Cvoid}}
    reserved_uint::NTuple{2, UInt64}
    reserved_size::NTuple{2, Csize_t}
    reserved_enum::NTuple{2, Cint}
end

Stream() =
    Stream(0, 0, 0, 0, 0, 0, 0, 0, (0, 0, 0, 0), (0, 0), (0, 0), (0, 0))

# lzma/container.h:
# lzma_ret lzma_easy_encoder(
#   lzma_stream *strm, uint32_t preset, lzma_check check);
function easy_encoder(stream, preset, check)
    return ccall(
        (:lzma_easy_encoder, liblzma),
        Ret,
        (Ref{Stream}, UInt32, Check),
        stream, preset, check)
end

# lzma/container.h:
# lzma_ret lzma_stream_decoder(
#   lzma_stream *strm, uint64_t memlimit, uint32_t flags);
function stream_decoder(stream, memlimit, flags)
    return ccall(
        (:lzma_stream_decoder, liblzma),
        Ret,
        (Ref{Stream}, UInt64, UInt32),
        stream, memlimit, flags)
end

# lzma/base.h:
# lzma_ret lzma_code(lzma_stream *strm, lzma_action action);
function code(stream, action)
    return ccall(
        (:lzma_code, liblzma),
        Ret,
        (Ref{Stream}, Action),
        stream, action)
end

# lzma/base.h:
# void lzma_end(lzma_stream *strm);
function finish(stream)
    return ccall(
        (:lzma_end, liblzma),
        Cvoid,
        (Ref{Stream},),
        stream)
end

end  # module LZMA

function genpoly(n)
    @assert n ≥ 1
    ex = :(a[1])
    for k in 2:n
        ex = :(fma($(ex), x, a[$(k)]))
    end
    return ex
end

@generated polynomial(
    x::Number,
    a::NTuple{n, Number},
) where n = genpoly(n)

# ビットを左回転するイテレータ
struct BitRotator{T <: Base.BitInteger}
    bits::T
end

# 初期状態を返す
Base.iterate(rot::BitRotator) = (rot.bits, 1)

# 次の反復を準備する（状態を表すk引数は初期位置からの距離）
function Base.iterate(rot::BitRotator, k::Int)
    x = rot.bits
    nbits = sizeof(x) * 8
    if k ≥ nbits
        return nothing
    end
    return bitrotate(x, k), k + 1
end

# イテレータの長さ（要素数）
Base.length(rot::BitRotator) = sizeof(rot.bits) * 8

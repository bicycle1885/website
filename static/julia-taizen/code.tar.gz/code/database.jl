# データベースのレコード
struct Record{T}
    serial::Int
    data::T
end

# データベース
struct Database{T}
    records::Vector{Record{T}}
end

# 空のデータベースのコンストラクタ
Database{T}() where T = Database{T}(Record{T}[])

# データベースに新しいレコードを追加
function Base.push!(db::Database{T}, item) where T
    serial = length(db.records)
    record = Record(serial, convert(T, item))
    push!(db.records, record)
    return db
end

# Othelloモジュールの定義開始
module Othello

# インターフェース（モジュール外から使う型や関数）
export User, RandomAI, play

# オセロ石
# -------

# 石は文字で表現
const Disk = Char
const DISK_EMPTY = '\u22c5'  # 空き '⋅'
const DISK_BLACK = '\u25cf'  # 黒石 '●'
const DISK_WHITE = '\u25cb'  # 白石 '○'

# 石を判定する便利関数
isblack(disk::Disk) = disk == DISK_BLACK
iswhite(disk::Disk) = disk == DISK_WHITE

# 石をひっくり返す関数
flip(disk::Disk) =
    isblack(disk) ? DISK_WHITE :
    iswhite(disk) ? DISK_BLACK :
    throw(ArgumentError("not flippable"))


# 盤上の位置
# --------

const Position = Tuple{Char, Int}  # 位置をタプルで表現
const N = 8                        # 盤の1辺のサイズ
const ROWS = 1:N                   # 行の範囲
const COLS = 'a':'a'+N-1           # 列の範囲

# 位置posを行列のインデックスに変換
pos2idx(pos::Position) = (pos[2], pos[1] - 'a' + 1)

# 位置posが盤上にあるかを判定
isonboard(pos::Position) = pos[2] in ROWS && pos[1] in COLS


# オセロ盤
# -------

# オセロ盤のデータ型
struct Board
    data::Matrix{Disk}  # 石の行列（2次元配列）でオセロ盤を表現
end

# オセロ盤を作るコンストラクタ
function Board()
    board = Board(fill(DISK_EMPTY, (N, N)))
    # 石の初期配置
    board[('d', 5)] = board[('e', 4)] = DISK_BLACK
    board[('d', 4)] = board[('e', 5)] = DISK_WHITE
    return board
end

# オセロ盤の石を見る操作
Base.getindex(board::Board, pos::Position) =
    board.data[pos2idx(pos)...]

# オセロ盤に石を置く操作
function Base.setindex!(board::Board, disk::Disk, pos::Position)
    board.data[pos2idx(pos)...] = disk
    return board
end

# オセロ盤の表示
function Base.show(output::IO, board::Board)
    disks = countdisks(board)
    print(output, "Board with $(disks.black) blacks")
    print(output, " and $(disks.white) whites:\n")
    print(output, "  ")
    for c in COLS
        print(output, ' ', c)  # 列の英字表示
    end
    for r in ROWS
        print(output, "\n ", r)  # 行の数字表示
        for c in COLS
            print(output, ' ', board[(c, r)])
        end
    end
end

# 盤上にある石のカウント
function countdisks(board::Board)
    black = white = 0
    for c in COLS, r in ROWS
        disk = board[(c, r)]
        if isblack(disk)
            black += 1
        elseif iswhite(disk)
            white += 1
        end
    end
    # 名前付きタプルを返す
    return (black = black, white = white)
end


# 石の打ち方
# --------

# 方向dirに対してひっくり返せる石を探索
function flips(board::Board, disk::Disk, pos::Position, dir::NTuple{2, Int})
    dir == (0, 0) && return nothing
    nflips = 0  # ひっくり返せる石の数
    # 自分の石を探索
    next = pos .+ dir
    while isonboard(next) && board[next] == flip(disk)
        nflips += 1
        next = next .+ dir
    end
    # 相手の石を挟めているかをチェック
    if nflips > 0 && isonboard(next) && board[next] == disk
        # ペアになる石の位置を返す
        return next
    else
        return nothing
    end
end

# 有効手か判定
function isvalidmove(board::Board, disk::Disk, pos::Position)
    isonboard(pos) &&
    !isblack(board[pos]) &&
    !iswhite(board[pos]) || return false
    dirs = ((u, v) for u in -1:1 for v in -1:1 if !(u == v == 0))
    return !all(isnothing, flips(board, disk, pos, dir) for dir in dirs)
end

# 石diskを位置posに置いたときの盤面boardの更新
function move!(board::Board, disk::Disk, pos::Position)
    isvalidmove(board, disk, pos) || throw(ArgumentError("invalid move"))
    board[pos] = disk
    for u in -1:1, v in -1:1
        dir = (u, v)  # ひっくり返す方向
        pair = flips(board, disk, pos, dir)
        isnothing(pair) && continue  # ひっくり返す石がなければスキップ
        next = pos .+ dir
        while next != pair
            board[next] = disk
            next = next .+ dir
        end
    end
    return board
end


# プレイヤー
# ---------

# 抽象的なプレイヤーの型
abstract type Player end

# ユーザの型
"""
An interactive human player.
"""
struct User <: Player
    name::String
end

# プレイヤー名を取得
name(user::User) = user.name

# ユーザに次の手を入力させる
function move(::User, ::Disk, ::Board)
    while true
        input = prompt("move> ")
        if isnothing(input) || lowercase(input) == "resign"
            return nothing
        elseif contains(input, r"^[a-h][1-8]$"i)
            c = lowercase(input[1])
            r = input[2] - '0'
            return (c, r)
        end
        println("Invalid input; try again (e.g. f5).")
    end
end

# プロンプトを表示して入力させる
function prompt(msg::String)
    print(msg)
    input = readline(stdin)
    return isopen(stdin) ? strip(input) : nothing
end

# 人工知能の型
"""
A foolish AI player playing random moves.
"""
struct RandomAI <: Player
    name::String
end

# プレイヤー名を取得
name(ai::RandomAI) = ai.name

# 人工知能に次の手を決めさせる
function move(::RandomAI, disk::Disk, board::Board)
    moves = Position[]
    for c in COLS, r in ROWS
        pos = (c, r)
        if isvalidmove(board, disk, pos)
            push!(moves, pos)
        end
    end
    return rand(moves)
end


# ゲーム
# -----

# ゲームの結果
struct Result
    board::Board                    # 終局盤面
    black::Player                   # 黒石を持ったプレイヤー　
    white::Player                   # 白石を持ったプレイヤー
    resigned::Union{Disk, Nothing}  # 投了した石の色
end

# 出力に使うマクロの読込み
using Printf: @printf

# 結果の表示
function Base.show(output::IO, result::Result)
    report(disk, count, player) =
        @printf output "%s×%2d %s\n" disk count name(player)
    disks = countdisks(result.board)
    report(DISK_BLACK, disks.black, result.black)
    report(DISK_WHITE, disks.white, result.white)
    resigned = result.resigned
    if isnothing(resigned)
        x = cmp(disks.black, disks.white)
        msg = x < 0 ? "white winned" :
              x > 0 ? "black winned" : "draw"
    else
        @assert isblack(resigned) || iswhite(resigned)
        color = isblack(resigned) ? "black" : "white"
        msg = "$(color) resigned"
    end
    print(output, msg)
end

# ゲームを開始する関数
"""
    play(; black, white)

Start playing a game.

# Arguments
- `black`:
    a player making the first move.
    `User` with a random name is the default.
- `white`:
    a player making the second move.
    `RandomAI` with a random name is the default.
"""
function play(;
    black::Player = User(randname(DISK_BLACK)),
    white::Player = RandomAI(randname(DISK_WHITE)),
)
    print("$(DISK_BLACK) $(name(black)) vs ")
    print("$(DISK_WHITE) $(name(white))\n")
    board = Board()  # 初期盤面の作成
    nextdisk = alternatedisks(board)  # 次に打つ石を決める関数
    while true
        println('\n', board)
        disk = nextdisk()  # 次の石を取得
        if isnothing(disk)
            # 双方次手なし
            return Result(board, black, white, nothing)
        end
        player = isblack(disk) ? black : white
        playername = name(player)
        println("$(disk) $(playername)'s turn")
        pos = getmove(player, disk, board)
        if isnothing(pos)
            # 投了
            println(playername, " has resigned.")
            return Result(board, black, white, disk)
        else
            @assert isvalidmove(board, disk, pos)
            move!(board, disk, pos)  # 石を設置
            println("$(playername) placed at $(pos[1])$(pos[2]).")
        end
    end
end

# プレイヤーの手を決定
function getmove(player::Player, disk::Disk, board::Board)
    while true
        pos = move(player, disk, board)
        if isnothing(pos) || isvalidmove(board, disk, pos)
            # 投了または有効手
            return pos
        end
        # 無効手（選び直し）
        println("You cannot move that position.")
    end
end

# プレイヤー名を生成
const BLACK_NAMES = ("Panther", "Hawk", "Stingray")
const WHITE_NAMES = ("Tiger", "Parrot", "Shark")
randname(disk::Disk) =
    isblack(disk) ? "Black $(rand(BLACK_NAMES))" :
    iswhite(disk) ? "White $(rand(WHITE_NAMES))" :
    throw(ArgumentError("invalid disk"))

# 「次の石を選ぶ関数（クロージャ）」を返す関数
function alternatedisks(board::Board)
    next = DISK_BLACK  # 初手は黒石
    canmove() =  # nextに打つ手があるかを判定
        any(isvalidmove(board, next, (c, r))
            for c in COLS, r in ROWS)
    return function ()  # クロージャを返す
        if !canmove()
            next = flip(next)
            canmove() || return nothing
        end
        disk = next
        next = flip(next)  # 次の石に状態を更新
        return disk
    end
end

end  # Othelloモジュールの定義終了

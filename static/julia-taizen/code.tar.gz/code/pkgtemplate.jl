using PkgTemplates

template = Template(
    # ~/workspace以下にパッケージを生成
    dir = "~/workspace",
    # Julia 1.6以降をサポート
    julia = v"1.6",
    # プラグインの設定
    plugins = [
        # テスト固有の環境を有効化
        Tests(project = true),
        # 自動化にGitHub Actionsを使用
        GitHubActions(),
        # カバレッジ報告にCodecovを使用
        Codecov(),
        # ドキュメント生成にDocumenter.jlを使用
        Documenter{GitHubActions}(),
    ]
)

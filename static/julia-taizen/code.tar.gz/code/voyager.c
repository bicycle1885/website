#include <stdio.h>

const char* message =
    "Hello from the children of planet Earth.";

void say_hello(void)
{
    printf("%s\n", message);
}

# アトミック型
mutable struct Atomic{T}
    @atomic data::T
end

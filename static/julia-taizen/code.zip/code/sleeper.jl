# sleep関数を呼び出す関数
function sleeper()
    sleep(1)
    for i in 1:15
        sleep(0.1)
    end
    deepsleeper(3)
end

# 再帰関数
function deepsleeper(n)
    if n ≤ 1
        sleep(1)
    else
        deepsleeper(n - 1)
    end
end

using Profile
sleeper()           # コンパイル
@profile sleeper()  # プロファイル
Profile.print()     # プロファイル結果の出力

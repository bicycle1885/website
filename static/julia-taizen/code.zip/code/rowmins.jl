# 各行の最小値を計算する関数（行優先）
function rowmins_row(A)
    a = A[:,begin]
    for i in axes(A, 1)
        for j in firstindex(A, 2)+1:lastindex(A, 2)
            @inbounds a[i] = min(A[i,j], a[i])
        end
    end
    return a
end

# 各行の最小値を計算する関数（列優先）
function rowmins_col(A)
    a = A[:,begin]
    for j in firstindex(A, 2)+1:lastindex(A, 2)
        for i in axes(A, 1)
            @inbounds a[i] = min(A[i,j], a[i])
        end
    end
    return a
end

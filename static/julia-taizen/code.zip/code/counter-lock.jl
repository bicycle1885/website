# ロックを使った排他制御
counter = 0
mutex = ReentrantLock()
Threads.@threads for i in 1:1_000_000
    global counter
    lock(mutex)
    # ←ここからクリティカルセクション
    counter += 1
    # ←ここまでクリティカルセクション
    unlock(mutex)
end
@show counter

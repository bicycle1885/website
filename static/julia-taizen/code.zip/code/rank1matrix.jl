using LinearAlgebra: norm, normalize, normalize!

# 階数が1以下の行列
struct Rank1Matrix{T} <: AbstractMatrix{T}
    # A = u * v'
    u::Vector{T}
    v::Vector{T}
end

# 基本操作
Base.size(A::Rank1Matrix) = (length(A.u), length(A.v))
Base.getindex(A::Rank1Matrix, i::Integer, j::Integer) =
    A.u[i] * A.v[j]

# Matrix型への変換
Matrix(A::Rank1Matrix) = A.u * A.v'

# 行列ベクトル積
Base.:*(A::Rank1Matrix, x::AbstractVector) = A.u * A.v'x

# 行列積
Base.:*(A::Rank1Matrix, B::Rank1Matrix) =
    Rank1Matrix(A.u * A.v'B.u, B.v)
Base.:*(A::Rank1Matrix, B::AbstractMatrix) =
    Rank1Matrix(A.u, B'A.v)
Base.:*(A::AbstractMatrix, B::Rank1Matrix) =
    Rank1Matrix(A * B.u, B.v)

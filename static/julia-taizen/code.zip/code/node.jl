# 木構造のノード
mutable struct Node
    index::Int
    parent::Node

    # 内部コンストラクタの定義
    Node(index::Integer) = new(index)
    Node(index::Integer, parent::Node) = new(index, parent)
end

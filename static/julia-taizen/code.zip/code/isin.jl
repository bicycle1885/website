# xがcolに含まれるか判定
function isin(x::T, col::Vector{T}) where T
    for y in col
        y == x && return true
    end
    return false
end

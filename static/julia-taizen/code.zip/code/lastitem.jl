function lastitem(xs)
    local last
    for x in xs
        last = x
    end
    return @isdefined(last) ? last : nothing
end

#!/usr/bin/env julia

include("LZMA.jl")

function transcode(
        input, output, mode;
        level = 6,  # compression level
        bufsize = 4 * 2^10,  # 4 KiB
        memlimit = 2^30,     # 1 GiB
    )
    # ストリームの初期化
    stream = LZMA.Stream()
    if mode == :encode
        ret = LZMA.easy_encoder(stream, level, LZMA.CHECK_CRC64)
    else
        mode == :decode || error("invalid transcoding mode")
        ret = LZMA.stream_decoder(stream, memlimit, LZMA.FLAG_CONCATENATED)
    end
    ret == LZMA.RET_OK ||
        error("failed to initialize stream encoder")
    # 入出力バッファの初期化
    inbuf = zeros(UInt8, bufsize)
    outbuf = zeros(UInt8, bufsize)
    buffered::Int = 0
    while ret != LZMA.RET_STREAM_END
        # 入力
        buffered += readbytes!(input, @view(inbuf[buffered+1:end]))
        # streamのセットアップ
        stream.next_in = pointer(inbuf)
        stream.avail_in = buffered
        stream.next_out = pointer(outbuf)
        stream.avail_out = length(outbuf)
        # エンコード
        action = eof(input) ?
            LZMA.ACTION_FINISH : LZMA.ACTION_RUN
        @debug "Calling LZMA.code" buffered action
        ret = LZMA.code(stream, action)
        ret == LZMA.RET_OK || ret == LZMA.RET_STREAM_END ||
            error("failed to $(mode) data: $(ret)")
        # 残りデータの移動
        Δin = buffered - stream.avail_in
        buffered = stream.avail_in
        copyto!(inbuf, 1, inbuf, Δin + 1, buffered)
        # 出力
        Δout = bufsize - stream.avail_out
        unsafe_write(output, pointer(outbuf), Δout)
    end
    LZMA.finish(stream)
end

mode = Symbol(ARGS[1])  # encode or decode
transcode(stdin, stdout, mode)

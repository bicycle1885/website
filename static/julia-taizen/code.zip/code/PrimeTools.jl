module PrimeTools

function isprime(n::Integer)
    if n ≤ 1
        return false
    end
    i = 2
    while i ≤ isqrt(n)
        if n % i == 0
            return false
        end
        i += 1
    end
    return true
end

end  # module

# base/timing.jl (MIT license: https://julialang.org/license)
macro elapsed(ex)
    quote
        local t0 = time_ns()
        $(esc(ex))
        (time_ns() - t0) / 1e9
    end
end

function loop(n)
    s = 0.0
    for i in 1:n
        s += sin(i) / i
    end
    return 2s + 1
end

using .Threads: @spawn

include("nqueens.jl")
include("nqueens-serial.jl")
include("nqueens-flat.jl")
include("nqueens-nested.jl")

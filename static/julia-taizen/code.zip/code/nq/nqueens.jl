#!/usr/bin/env julia

# 列fileにクイーンを置き、再帰的に解を数え上げる
function solve(ranks, file)
    n = length(ranks)
    nsols = 0  # 解の数
    for rank in 1:n
        for i in 1:file-1
            @inbounds r = rank - ranks[i]
            if r == 0 || file - i == abs(r)
                # 横か斜めにクイーンがあるので次の行に移る
                @goto next
            end
        end
        # (file, rank)にクイーンを置く
        ranks[file] = rank
        # 次の列に移る（既に最後の列なら解を1つ発見）
        nsols += file < n ? solve(ranks, file + 1) : 1
        @label next
    end
    return nsols
end

# nクイーン問題の解を数え上げる
nqueens(n) = n ≤ 0 ? 0 : solve(zeros(Int, n), 1)

# コマンドラインから呼び出されたときのエントリーポイント
if abspath(PROGRAM_FILE) == @__FILE__
    let
        n = parse(Int, ARGS[1])
        println(n, ": ", nqueens(n))
    end
end

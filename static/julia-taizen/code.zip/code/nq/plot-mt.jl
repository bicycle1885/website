using CSV
using DataFrames
using PyPlot
using Statistics

datafile, plotfile = ARGS
data = DataFrame(CSV.File(datafile, delim = '\t'))
par1 = data[data.func .== "flat",:]
par2 = data[data.func .== "nested",:]
par1.speedup = par1.elapsed .\ median(par1[par1.nthreads .== 1,:elapsed])
par2.speedup = par2.elapsed .\ median(par2[par2.nthreads .== 1,:elapsed])

fig, ax = subplots(figsize = (8, 5))
marker = "x"
ax.scatter(par1.nthreads, par1.speedup, label = first(par1.func); marker)
ax.scatter(par2.nthreads, par2.speedup, label = first(par2.func); marker)
ax.axline((0, 0), slope = 1, ls = "dotted", c = "gray")
ax.legend()
ax.grid(alpha = 1/2)
ax.spines["top"].set_visible(false)
ax.spines["right"].set_visible(false)
ax.set_xlim(0, nothing)
ax.set_ylim(0, nothing)
ax.set_xlabel("# threads")
ax.set_ylabel("speedup")
fig.savefig(plotfile, bbox_inches = "tight")

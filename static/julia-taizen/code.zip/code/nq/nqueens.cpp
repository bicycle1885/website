#include <vector>
#include <iostream>
#include <cstdint>
#include <cstdlib>

int64_t solve(std::vector<int> &ranks, const int file)
{
    int n = ranks.size();
    int64_t nsols = 0;
    for (int rank = 0; rank < n; ++rank) {
        for (int i = 0; i < file; ++i) {
            auto r = rank - ranks[i];
            if (r == 0 || file - i == abs(r))
                goto next;
        }
        ranks[file] = rank;
        nsols += file < n - 1 ? solve(ranks, file + 1) : 1;
        next:;
    }
    return nsols;
}

int64_t nqueens(int n)
{
    std::vector<int> ranks(n, 0);
    return solve(ranks, 0);
}

int main(int argc, char* argv[])
{
    int n = std::stoi(argv[1]);
    std::cout << n << ": " << nqueens(n) << std::endl;
}
# ネスト並列
function nqueens_nested(n)
    n ≤ 0 && return 0
    return parsolve(zeros(Int, n), 1)
end

# solve関数の並列版
function parsolve(ranks, file)
    n = length(ranks)
    n - file < 12 && return solve(ranks, file)
    tasks = map(1:n) do rank
        @spawn begin
            for i in 1:file-1
                r = rank - ranks[i]
                if r == 0 || file - i == abs(r)
                    return 0
                end
            end
            let ranks = copy(ranks)
                ranks[file] = rank
                return parsolve(ranks, file + 1)
            end
        end
    end
    return sum(fetch(task)::Int for task in tasks)
end

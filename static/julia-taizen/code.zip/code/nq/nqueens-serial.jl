# 逐次実行
function nqueens_serial(n)
    n ≤ 0 && return 0
    return solve(zeros(Int, n), 1)
end

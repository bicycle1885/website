#!/usr/bin/env julia

include("nqueens.jl")
include("nqueens-mt.jl")

using Test

@testset "nqueens" begin
    @test nqueens(0) == 0
    @test nqueens(1) == 1
    @test nqueens(2) == 0
    @test nqueens(3) == 0
    @test nqueens(8) == 92
end

@testset "nqueens_serial" begin
    @test nqueens_serial(0) == 0
    @test nqueens_serial(1) == 1
    @test nqueens_serial(2) == 0
    @test nqueens_serial(3) == 0
    @test nqueens_serial(8) == 92
end

@testset "nqueens_flat" begin
    @test nqueens_flat(0) == 0
    @test nqueens_flat(1) == 1
    @test nqueens_flat(2) == 0
    @test nqueens_flat(3) == 0
    @test nqueens_flat(8) == 92
end

@testset "nqueens_nested" begin
    @test nqueens_nested(0) == 0
    @test nqueens_nested(1) == 1
    @test nqueens_nested(2) == 0
    @test nqueens_nested(3) == 0
    @test nqueens_nested(8) == 92
end

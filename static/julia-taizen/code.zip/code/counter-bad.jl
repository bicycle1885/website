# 誤った実装！
counter = 0
Threads.@threads for i in 1:1_000_000
    global counter
    counter += 1
end
@show counter

# 構造体型の構造を出力
function reportfields(T)
    println(T)
    for i in 1:fieldcount(T)
        name = fieldname(T, i)
        type = fieldtype(T, i)
        println("  [$(i)] $(name) :: $(type)")
    end
end

# f文字列の解析処理
function parse_fstring(str)
    parts = Union{String, Symbol}[]
    pos = firstindex(str)
    # '{'を探す
    while (open = findnext('{', str, pos)) !== nothing
        # '}'を探す
        close = findnext('}', str, open)
        isnothing(close) && break  # ペアになる'}'がない
        # '{'より前までを詰める
        push!(parts, str[pos:prevind(str, open)])
        # '{'と'}'の間の名前を詰める（空文字列ならそのまま）
        name = str[nextind(str, open):prevind(str, close)]
        push!(parts, isempty(name) ? "{}" : Symbol(name))
        # '}'の直後の位置を取得する
        pos = nextind(str, close)
    end
    # 残りの文字列を詰める
    push!(parts, str[pos:end])
    return parts
end

# マクロの定義
macro f_str(str)
    parts = parse_fstring(str)
    # 変数（シンボル）はエスケープする
    parts = map(x -> x isa Symbol ? esc(x) : x, parts)
    return :(string($(parts...)))
end

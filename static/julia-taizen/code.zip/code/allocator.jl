# メモリを割り当てる関数
function allocator(n)
    zeros(n)
    zeros(n, n)
    zeros(n, n, n)
end

using Profile
allocator(1)                 # コンパイル
Profile.clear_malloc_data()  # リセット
allocator(100)               # プロファイル

# nが素数かを判定
function isprime(n)
    for i in 2:isqrt(n)
        if n % i == 0
            # 約数が見つかったので素数ではない
            return false
        end
    end
    # 約数がなかったので素数である
    return true
end

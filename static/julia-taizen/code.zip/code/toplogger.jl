# topコマンドの1行目をlog.txtファイルに追記
toplogger = pipeline(
    pipeline(`top -b`, stdout = `head -1`),
    stdout = "log.txt",
    append = true,
)

# 1秒間隔で10回実行
for _ in 1:10
    run(toplogger)
    sleep(1)
end

using Images

const Img = Array{RGB{N0f8}}

# 逐次実行
function histogram_serial(img::Img)
    hist_r = zeros(Int, 256)
    hist_g = zeros(Int, 256)
    hist_b = zeros(Int, 256)
    @inbounds for i in eachindex(img)
        x = img[i]  # 画素（pixel）
        hist_r[reinterpret(UInt8, x.r)+1] += 1
        hist_g[reinterpret(UInt8, x.g)+1] += 1
        hist_b[reinterpret(UInt8, x.b)+1] += 1
    end
    return hist_r, hist_g, hist_b
end

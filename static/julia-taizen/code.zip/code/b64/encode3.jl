# ルックアップテーブル
const ENCODE_TABLE = UInt8['A':'Z'; 'a':'z'; '0':'9'; '+'; '/']

# Base64符号化関数（バージョン3）
function encode3(data::AbstractVector{UInt8})
    str = zeros(UInt8, cld(sizeof(data), 3) * 4)
    i = firstindex(data)
    j = firstindex(str)
    @inbounds while i + 2 ≤ lastindex(data)
        x1, x2, x3 = data[i], data[i+1], data[i+2]
        i += 3
        h1 =                  x1 >> 2
        h2 = x1 << 4 & 0x3f | x2 >> 4
        h3 = x2 << 2 & 0x3f | x3 >> 6
        h4 = x3      & 0x3f
        str[j  ] = ENCODE_TABLE[h1+1]
        str[j+1] = ENCODE_TABLE[h2+1]
        str[j+2] = ENCODE_TABLE[h3+1]
        str[j+3] = ENCODE_TABLE[h4+1]
        j += 4
    end
    finish!(str, data, lastindex(data) - i + 1)
    return str
end

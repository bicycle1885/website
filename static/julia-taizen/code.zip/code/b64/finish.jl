# 符号化文字列末尾の処理関数
function finish!(str::Vector{UInt8}, data::AbstractVector{UInt8}, n::Integer)
    if n == 0
        # do nothing
    elseif n == 1
        str[end-3] = hex2char(data[end] >> 2)
        str[end-2] = hex2char(data[end] << 4 & 0x3f)
        str[end-1] = str[end] = UInt8('=')  # padding
    elseif n == 2
        str[end-3] = hex2char(data[end-1] >> 2)
        str[end-2] = hex2char(data[end-1] << 4 & 0x3f | data[end] >> 4)
        str[end-1] = hex2char(data[end]   << 2 & 0x3f)
        str[end]   = UInt8('=')  # padding
    end
    return str
end

using Test
using Random

include("rank1matrix.jl")

@testset "Rank1Matrix" begin
    Random.seed!(1234)
    u, v = randn(5), randn(6)
    A = Rank1Matrix(u, v)
    @test size(A) == (5, 6)
    @test A[1,1] ≈ u[1] * v[1]
    @test A[1,2] ≈ u[1] * v[2]
    @test A[2,1] ≈ u[2] * v[1]
    @test A[2,2] ≈ u[2] * v[2]
    @test Matrix(A) ≈ u * v'

    x, y = randn(6), randn(7)
    @test A * x ≈ Matrix(A) * x

    B = Rank1Matrix(x, y)
    AB = u * v'x * y'
    @test Matrix(A * B) ≈ AB
    @test A * Matrix(B) ≈ AB
    @test Matrix(A) * B ≈ AB
end

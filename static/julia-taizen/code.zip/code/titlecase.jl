#!/usr/bin/env julia
line = readline(stdin)
println(stdout, titlecase(line))

using PyCall

# モジュールの読込みと関数定義
py"""
import textwrap

# wraptextはテキストを適当なところで折り返す
def wraptext(text, width=50):
    return "\n".join(textwrap.wrap(text, width=width))
"""

# 関数の取得
wraptest = py"wraptext"

# 実行例
longtext = "Julia was designed from the beginning for high performance. Julia programs compile to efficient native code for multiple platforms via LLVM."
println(wraptest(longtext))
## Julia was designed from the beginning for high
## performance. Julia programs compile to efficient
## native code for multiple platforms via LLVM.

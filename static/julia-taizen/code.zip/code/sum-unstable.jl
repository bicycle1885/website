# 型が安定していないsum関数の実装
function sum_unstable(xs)
    s = 0
    for x in xs
        s += x
    end
    return s
end

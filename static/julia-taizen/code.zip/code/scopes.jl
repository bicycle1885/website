module Foo
# G: global scope
g = 0

function bar()
    # L1: local scope
    l1 = 1
end

function baz()
    # L2: local scope
    l2 = 2

    for _ in 1:9
        # L3: local scope
        l3 = 3
    end

    for _ in 1:9
        # L4: local scope
        l4 = 4
    end
end

end  # module Foo

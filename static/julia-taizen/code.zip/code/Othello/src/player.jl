# プレイヤー
# ---------

# 抽象的なプレイヤーの型
abstract type Player end

# ユーザの型
"""
An interactive human player.
"""
struct User <: Player
    name::String
end

# プレイヤー名を取得
name(user::User) = user.name

# ユーザに次の手を入力させる
function move(::User, ::Disk, ::Board)
    while true
        input = prompt("move> ")
        if isnothing(input) || lowercase(input) == "resign"
            return nothing
        elseif contains(input, r"^[a-h][1-8]$"i)
            c = lowercase(input[1])
            r = input[2] - '0'
            return (c, r)
        end
        println("Invalid input; try again (e.g. f5).")
    end
end

# プロンプトを表示して入力させる
function prompt(msg::String)
    print(msg)
    input = readline(stdin)
    return isopen(stdin) ? strip(input) : nothing
end

# 人工知能の型
"""
A foolish AI player playing random moves.
"""
struct RandomAI <: Player
    name::String
end

# プレイヤー名を取得
name(ai::RandomAI) = ai.name

# 人工知能に次の手を決めさせる
function move(::RandomAI, disk::Disk, board::Board)
    moves = Position[]
    for c in COLS, r in ROWS
        pos = (c, r)
        if isvalidmove(board, disk, pos)
            push!(moves, pos)
        end
    end
    return rand(moves)
end


# ゲーム
# -----

# ゲームの結果
struct Result
    board::Board                    # 最終盤面
    black::Player                   # 黒石を持ったプレイヤー　
    white::Player                   # 白石を持ったプレイヤー
    resigned::Union{Disk, Nothing}  # 投了した石の色
end

# 出力に使うマクロの読込み
using Printf: @printf

# 結果の表示
function Base.show(output::IO, result::Result)
    report(disk, count, player) =
        @printf output "%s×%2d %s\n" disk count name(player)
    disks = countdisks(result.board)
    report(DISK_BLACK, disks.black, result.black)
    report(DISK_WHITE, disks.white, result.white)
    resigned = result.resigned
    if isnothing(resigned)
        x = cmp(disks.black, disks.white)
        msg = x < 0 ? "white winned" :
              x > 0 ? "black winned" : "draw"
    else
        @assert isblack(resigned) || iswhite(resigned)
        color = isblack(resigned) ? "black" : "white"
        msg = "$(color) resigned"
    end
    print(output, msg)
end

# ゲームを開始する関数
"""
    play(; black, white)

Start playing a game.

# Arguments
- `black`:
    a player who does the first move.
    `User` with a random name is the default.
- `white`:
    a player who does the second move.
    `RandomAI` with a random name is the default.
"""
function play(;
    black::Player = User(randname(DISK_BLACK)),
    white::Player = RandomAI(randname(DISK_WHITE)),
)
    print("$(DISK_BLACK) $(name(black)) vs ")
    print("$(DISK_WHITE) $(name(white))\n")
    board = Board()  # 初期盤面の作成
    nextdisk = alternatedisks(board)  # 次に打つ石を決める関数
    while true
        println('\n', board)
        disk = nextdisk()  # 次の石を取得
        if isnothing(disk)
            # 双方次手なし
            return Result(board, black, white, nothing)
        end
        player = isblack(disk) ? black : white
        playername = name(player)
        println("$(disk) $(playername)'s turn")
        pos = getmove(player, disk, board)
        if isnothing(pos)
            # 投了
            println(playername, " has resigned.")
            return Result(board, black, white, disk)
        else
            @assert isvalidmove(board, disk, pos)
            move!(board, disk, pos)  # 石を設置
            println("$(playername) placed at $(pos[1])$(pos[2]).")
        end
    end
end

# プレイヤーの手を決定
function getmove(player::Player, disk::Disk, board::Board)
    while true
        pos = move(player, disk, board)
        if isnothing(pos) || isvalidmove(board, disk, pos)
            # 投了または有効手
            return pos
        end
        # 無効手（選び直し）
        println("You cannot move that position.")
    end
end

# プレイヤー名を生成
const BLACK_NAMES = ("Panther", "Hawk", "Stingray")
const WHITE_NAMES = ("Tiger", "Parrot", "Shark")
randname(disk::Disk) =
    isblack(disk) ? "Black $(rand(BLACK_NAMES))" :
    iswhite(disk) ? "White $(rand(WHITE_NAMES))" :
    throw(ArgumentError("invalid disk"))

# 「次の石を選ぶ関数（クロージャ）」を返す関数
function alternatedisks(board::Board)
    next = DISK_BLACK  # 初手は黒石
    canmove() =  # nextに打つ手があるかを判定
        any(isvalidmove(board, next, (c, r))
            for c in COLS, r in ROWS)
    return function ()  # クロージャを返す
        if !canmove()
            next = flip(next)
            canmove() || return nothing
        end
        disk = next
        next = flip(next)  # 次の石に状態を更新
        return disk
    end
end

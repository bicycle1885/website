# Othelloモジュールの定義開始
module Othello

# インターフェース（モジュール外から使う型や関数）
export User, RandomAI, play

include("disk.jl")
include("position.jl")
include("board.jl")
include("player.jl")
include("game.jl")

end  # Othelloモジュールの定義終了

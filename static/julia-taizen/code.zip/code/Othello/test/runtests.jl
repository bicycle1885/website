using Othello
using Test

# 何度も使う変数は取り込んでおく
using Othello: DISK_EMPTY, DISK_WHITE, DISK_BLACK

# テストケースのグループ化
@testset "Othello.jl" begin
    # flip関数のテスト
    @test Othello.flip(DISK_WHITE) == DISK_BLACK
    @test Othello.flip(DISK_BLACK) == DISK_WHITE
    # ArgumentErrorが発生することをテスト
    @test_throws ArgumentError Othello.flip(DISK_EMPTY)
end

# s1とs2のメモリ比較（o1とo2はオフセット）
function memcmp(x1, o1, x2, o2)
    n = min(sizeof(x1) - o1, sizeof(x2) - o2)
    GC.@preserve x1 x2 begin
        s1 = pointer(x1) + o1
        s2 = pointer(x2) + o2
        # int memcmp(void *s1, void *s2, size_t n);
        return ccall(
            :memcmp,
            Cint,
            (Ptr{Cvoid}, Ptr{Cvoid}, Csize_t),
            s1, s2, n)
    end
end

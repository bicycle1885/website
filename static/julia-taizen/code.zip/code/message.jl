"""
A data type to represent a message.
"""
struct Message
    from::String
    content::String
end

"""
    send(msg, to[; anonymous = false])

Send a message `msg` to a person `to`.

It sends the message and returns the number of written bytes.

# Examples
```jldoctest
julia> msg = Message("Alice", "Hi, how have you been?");

julia> send(msg, "Bob")
30
```
"""
function send(
    msg::Message,
    to::AbstractString;
    anonymous::Bool = false,
)
    from = anonymous ? "?" : msg.from
    data = "[$from] $(msg.content)"
    return write(devnull, data)
end

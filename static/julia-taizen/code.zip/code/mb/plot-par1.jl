# 並列実行版1
function plot_par1(x, y; maxiters = N)
    m, n = length.((y, x))
    img = zeros(Int16, m, n)
    Threads.@threads :static for j in 1:n
        for i in 1:m
            c = complex(x[j], y[i])
            img[i,j] = mandelbrot(c; maxiters)
        end
    end
    return img
end

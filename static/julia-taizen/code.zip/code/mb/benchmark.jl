#!/usr/bin/env -S julia -t4

include("mandelbrot.jl")
include("plot-seq.jl")
include("plot-par1.jl")
include("plot-par2.jl")

# check
x = y = range(-2, 2, length = 101)
@assert plot_seq(x, y) == plot_par1(x, y) == plot_par2(x, y)

x = range(-2.0, 0.8, length = 10001)
y = range(-1.4, 1.4, length = 10001)
for plot in [plot_seq, plot_par1, plot_par2]
    @elapsed plot(x, y, maxiters = 5)  # compile
    for i in 1:3
        elapsed = @elapsed plot(x, y)
        println(plot, '\t', i, '\t', elapsed)
    end
end

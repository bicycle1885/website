# 逐次実行版
function plot_seq(x, y; maxiters = 1000)
    m, n = length.((y, x))
    img = zeros(Int16, m, n)
    for j in 1:n, i in 1:m
        c = complex(x[j], y[i])
        img[i,j] = mandelbrot(c; maxiters)
    end
    return img
end

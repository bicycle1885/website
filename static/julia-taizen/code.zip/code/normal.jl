# 正規分布（normal distribution）
struct Normal{T <: Real}
    μ::T  # 平均
    σ::T  # 標準偏差

    # 内部コンストラクタ
    function Normal{T}(μ::Real = 0, σ::Real = 1) where T <: Real
        σ > 0 || throw(ArgumentError("σ must be positive"))
        return new{T}(μ, σ)
    end
end

# 外部コンストラクタ
function Normal(μ::Real = 0, σ::Real = 1)
    μ, σ = promote(float(μ), float(σ))
    return Normal{typeof(μ)}(μ, σ)
end

# 確率密度関数
function pdf(dist::Normal, x::Real)
    # Julia 1.7以降では (; μ, σ) = dist も可
    μ, σ = dist.μ, dist.σ
    return (σ * oftype(σ, √(2π))) \ exp(-2 \ ((x - μ) / σ)^2)
end

# 短い（7バイト以下）ASCII文字列のデータ型
struct ShortString # <: AbstractString
    data::UInt64
end

# コンストラクタ
ShortString(s::String) = convert(ShortString, s)

# String → ShortStringの変換
function Base.convert(::Type{ShortString}, s::String)
    n = ncodeunits(s)
    if n > 7 || !isascii(s) || '\0' in s
        throw(InexactError(:ShortString, ShortString, s))
    end
    data = zero(UInt64)
    for i in n:-1:1
        data = (data << 8) | codeunit(s, i)
    end
    return ShortString(data)
end

# ShortString → Stringの変換
Base.convert(::Type{String}, s::ShortString) = sprint(print, s)

# show関数の拡張
Base.show(out::IO, s::ShortString) = show(out, convert(String, s))

# print関数の拡張
function Base.print(out::IO, s::ShortString)
    data = s.data
    while data & 0xff != 0
        write(out, data % UInt8)
        data >>= 8
    end
end

using Test

include("circle.jl")

@testset "circle" begin
    r = 2.1
    @test diameter(r) ≈ 4.2
    @test circumference(r) ≈ 13.194689145077131
    @test area(r) ≈ 13.854423602330987
end

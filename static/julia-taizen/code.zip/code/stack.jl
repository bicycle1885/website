mutable struct Stack{T}
    data::Vector{T}  # 要素
    size::Int        # 要素数

    function Stack{T}(; capacity::Integer = 4) where T
        data = Vector{T}(undef, capacity)
        return new{T}(data, 0)
    end
end

Stack(; capacity::Integer = 4) = Stack{Any}(; capacity)

Base.eltype(::Type{Stack{T}}) where T = T
Base.length(stack::Stack) = stack.size
Base.isempty(stack::Stack) = stack.size == 0

function Base.push!(stack::Stack, item)
    item = convert(eltype(stack), item)
    if stack.size == length(stack.data)
        # stack.dataがいっぱいなら、サイズを2倍に拡大
        resize!(stack.data, max(2 * stack.size, 4))
    end
    newsize = stack.size + 1
    stack.data[newsize] = item
    stack.size = newsize
    return stack
end

function Base.pop!(stack::Stack)
    isempty(stack) && throw(ArgumentError("cannot pop! an empty stack"))
    item = stack.data[stack.size]
    stack.size -= 1
    return item
end

@generated function genfun(x)
    if x <: Real
        return :(println("$(repr(x)) is Real"))
    else
        return :(println("$(repr(x)) is not Real"))
    end
end

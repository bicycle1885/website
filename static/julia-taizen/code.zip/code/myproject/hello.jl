using Example: hello

println(hello(ARGS[1]))

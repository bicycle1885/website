# 通常の関数定義
function fib(n)
    if n ≤ 2
        return 1
    else
        return fib(n - 1) + fib(n - 2)
    end
end

# 1行関数定義
fib(n) = n ≤ 2 ? 1 : fib(n - 1) + fib(n - 2)

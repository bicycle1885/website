# RGB色モデル（true color）
struct RGB
    r::UInt8  # 赤（red）
    g::UInt8  # 緑（green）
    b::UInt8  # 青（blue）

    # 内部コンストラクタ
    function RGB(r::Integer, g::Integer, b::Integer)
        0 ≤ r ≤ 255 && 0 ≤ g ≤ 255 && 0 ≤ b ≤ 255 ||
        throw(ArgumentError("value must be between 0 and 255"))
        return new(r, g, b)
    end
end

# 無彩色を作る外部コンストラクタ
RGB(x::Integer) = RGB(x, x, x)
